# Capturing It

I find myself captivated in the attempt to fathom what we are. The miracle visible at every given moment, that we are truly nothing less than the fullness of being. We are as human, the expression of every possibility, from weakness to greatness, we can experience scaling being fantastic and mundane, from depravity to divinity.

We are often striving for better, searching for greater, needing to be okay. We shy from uncertainty, fragility, despair, torments and sufferings, heartaches and cruelties.

It is often easy to believe that we would always be okay if we could hold onto one familiarized state. Our thoughts say, if we always felt this one way, then we'll be okay forever. And yet while we may try to build ourselves up to condition to such a state such that we never fall again, we can surely expect to return to and navigate through every possible state of being as long as we are alive.

I cannot begin to appreciate such a miracle. I often take comfort in knowing that I am part of the whole being of humanity that is temporarily witnessing an aspect of all from a personalized view, every imperfection in life as equally lovable as you would love the whole of your soulmate. You don't love them less for having scars. You don't love someone's shoulder less than the elbow because it is simply one body, as it is.

My captivation is in that the beauty of being is always there to be found if it is searched for by the one who has the eyes to perceive it, most often the harder it is to find, the quieter one must become for it to come to light.

To me the most beautiful is the most elusive, the most hidden, only found in the roughest of people, the hardest of times, the strife of strifes, the thickest of fields, the darkest of nights, the brightest of lights, the strongest of sorrows. It is often near silence or silence itself, amidst the orchestra of life.

It feels as though to begin to express the feeling of wonder of this beauty, that if I begin to speak of it, to focus my gaze on it too intently, it might begin to vanish. I can only hope to learn to hold it softly that the wonderment grows into a mass that will be so familiar that it is never far from view. I feel my greatest regret could never be to fail or take the wrong path or to make the wrong choices, my only greatest regret would be being and not being, killing that sacred essence, that undying spark. I could only regret to try to hide from being, or attempt to choose one part of it and deny the other.

Imagine loving someone's shoulder and not their elbow! Imagine trying to be less than the fullness of being alive!