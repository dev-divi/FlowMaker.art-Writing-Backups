# To Everyone Who Hates God

To everyone who hates God because of the church 
this is the great sin of the church 
in the hatred of the church they have created 
they have stolen God from you, 
if you think about this, 
if you allow them to have stolen God from you, 
in creating hatred for what they represent, 
in their creation of your unforgiveness, 
you allow the church to win against you, 
you allow them to steal from you

They have raised the light high, 
and attacked you, 
they have committed a crime, 
but their bigger crime, 
is to push you away from the light, 

because their attack hurts, 
the light also hurts, 
and these two hurts become associated as one, 

this is how they have systematically stolen the light from the people, 
this is how they have committed warfare and robbery, 
their enemies are destroyed in darkness, 
while they grow stronger by holding themselves near the light 

the only way to win against the church is to take that light back for yourself

I can feel it all, because I have had it, 
the bitterness, 
I know it, I know that experience, 
I know the feeling, that ting in the soul when you hear the word "god" 
when that word reminds you of rejection, 

what they did is they took something sacred, something sacred inside you, 
the most sacred thing inside of you, 
and they turned it into a reminder of pain

by creating this pain, 
they make you want to shield yourself from the light, 
so that the light makes you flinch when you see it, 
when you see them, 
they in their hardness of hearts profit off of this, 
they profit off of their followers and they profit more from their enemies 

but when you have the light, 
you have no enemies, 
once you forgive the church, 
once you reconnect with the sacred inside of you, 

you don't have to have enemies, 
because you don't have to shield yourself from light, 
you don't have to be on the defensive, 
you can be only offensive

when the light is associated with what hurts us 
we want to cover into darkness to make that pain go away, 
but that darkness begins to kill us, 
and we feel a confliction inside of us, 
because that darkness doesn't resonate with our core self, 

but our soul begins to saturate with the darkness, 
so that the darkness becomes normal, 
the pain becomes normal, the suffering becomes normal, 
the agony and the torment becomes normal, 
and the normal torments seem better than the sting from that light, 
that light which now hurts our entire soul

but if you reconnect with the sacred in your core and honor it again, 
and remove the hatred that has grown for your attackers, 
the sacred in your core begins to reach out to other places inside of you 
you begin to heal, 
what was tormented and painful becomes a spring meadow again, 
those areas you have to defend against being triggered, 
those areas get exposed to the light, 
and there is release, 
the release you are looking for every time you choose a vice to try to escape, 
the rocks that have sat in your soul begin to rise to the surface, 
they transform and become weightless and they lift out of you, 
they float out of you and when they do, 
you feel as though millions of little nails and thorns are rising out of your chest 
this feels like opium, it is though gravity has reversed and that which rises to the surface is exposed to air 
and turns into fresh breath

The church has done so much more than stolen the sacred from you
They have taken the structure, foundations, ways that would allow you to be the best version of yourself
to live your most healthy life, your most enjoyable existence,
by associating those too with themselves

They rob you not only of the spiritual, but of the physical too
All that you allow them to take and turn against you.