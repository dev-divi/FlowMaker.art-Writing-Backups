# Question Clarity

*"If you ask the right question, you will receive the right answer",*
To clarify, I am talking about a clarity.
I am not saying,
*"The question you ask is the answer you receive".*

By asking the wrong question, you receive the wrong answer.
This is to say,
If you ask the question the right way, you will receive the answer the right way.

How clear your question is determines the clarity of the answer.