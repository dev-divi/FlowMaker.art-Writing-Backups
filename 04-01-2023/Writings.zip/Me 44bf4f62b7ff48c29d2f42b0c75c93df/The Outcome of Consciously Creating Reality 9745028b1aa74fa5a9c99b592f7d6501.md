# The Outcome of Consciously Creating Reality

We can creatively decide how we choose to be, 

by the way we choose, 

we can inject that creation into reality. 

Consciously doing this is 100% more effective than not doing so. 
If you intentionally create your reality, you are not only 100% effective,
you are also 100% more effective than everyone around you whom are not consciously creating reality at all,
which is why they say,

> *“The world belongs to the creatives.”*
> 

In getting away from the usual thoughts and allowing back in creative thoughts,

there are two additional steps you can take in terms of creating reality.

The first is of course choosing the way you want to be.

The second is harder to articulate, and that's why I have been starting with,

<aside>
💡 "What if you were in the driver's seat of your own life, what if you took different actions than the person of you would usually do?"

</aside>

There's certain positioning of self necessary for this, you do need to be closer to the place of your being and far from self to do this,
you would have to look at life as though you are in a dream,
questioning *“Who am I right now?”*
The who you actually are right now could do anything.
The who you think you are in thinking is limited.

If you look through that perspective that life is a dream,  

*—hopefully without deluding yourself in a mind-game—*
and you are in the present moment,
You can take this second step and also be a little spontaneous in your day.

What do I mean by that?

Have you ever noticed that when you are really happy, you're more likely to have different than usual behavior,
you're more likely to do and say things you would normally not say,
because you know it doesn't matter and no one is going to take that state from you.

Well, if you're being present and looking at life in this way,
you can add a little spice to your day by getting a little creative and unconventional with your choices.
In a sense you can mess with the story just a bit, you can hack the matrix just a bit,
If you do this in a positive way you can get some pretty profound results.
Even if you do this in a negative way you can get some results(though not advised).

You know when you just don't care anymore and you hit that point where all you can do is laugh?
This is like that, but what we're really talking about is applying the same trait of creative ability, of artistic flair,
of activating that part of the mind and applying it to life instead of to a picture.
This means activating that questioning, curious, explorative part and experimenting a bit.

This isn't a "way" and it isn't going to save your life and it isn't going to be an ultimate solution,
but it can cause you to enjoy your day much more, and your day is all you have, and can bring back a little fun, and it can change your perspective,
and it can bring a little light to your world, and it can bring you closer to your authentic nature because that creative state is close to who you are and your authenticity.

That's only one piece of the puzzle is why I say it isn't "the way" and it isn't "the perspective" and it isn't "purpose" but it is a bit worthwhile.

There is power and there are possibilities gained when you access this.

You not only gain an edge against fear, but this could lead you to the point of that truth that *"the world belongs to the creatives"*,
because if you were to be able to make those kinds of conscious choices regularly,
you not only destroy some personal fear and limitation,
but you also would become a person who really can do anything,
and not because of your abilities or self,
but because you're being the kind of person who makes those kinds of choices and changes. 

Who is that kind of person?

That kind of person is the kind of person with the freedom to make new choices, to go in new directions, to become something different than what they were.

Imagine the kind of perspective that someone like that would have,
if you really believed that you were in a dream,
what decision could you not make?

We only use our logical brain to make careful safe choices because we are afraid of our self being destroyed,
we're afraid of the consequences of the real world.

If you really believed you were in a dream, or if you really believed you were in a videogame,
I guarantee you would act very differently.

There is a little flavor of destruction in what I'm talking about,

but because you'd be conscious and closer to that authenticity,
the creativity coming out of you would be a lot of goodness and express a lot more of your authentic traits of joy and worth,

far more goodness than if you had acted uncreatively, in unawareness.

Try sitting in the driver's seat of your avatar, be understanding and empathetic to that avatar,
and take the wheel. 

If not actually believing you are in a dream,
perhaps just for a while you can pretend it is a dream and experiment with the results.