# Two Ways to Actualize Change

Two things I want to share that you already know.
Both have to do with actualizing change in your life.
The first is why it is so important to understand that you become the world around you. If you truly know this, if you can remove yourself from your world so that you can see that you do not exist without it, you can see how change works.
Making small changes and commitments to new things never works, why is that?
It's because you become the world around you. The things you actually start doing in lifestyle are the things that those around you are doing.
You never gain the motivation to change your lifestyle.
The only way your lifestyle ever changes is if the people around you are living a different lifestyle.
A different world prompts a different amount of energy from you.

If you look back at times in your life when you were doing more,
think about who you were around during those times.
The only way to change the people who are around you are when you become more selective about who you associate with,
and when you change what you think about.
When you change what you think about, you change what you talk about,
and the people who talk about those things invite you into their world.

The second thing I want to share is why prayer works and is essential to life.
The reason you need to pray for what you want to change in yourself is because you at this moment know what you want to change,
and you have ideas, concepts, and understandings of how to change it.
The options and paths you have in front of you to reach your goal,
your desired outcome,
are limited to what you are aware of.
The solutions you know you could take to solve your problem may not be worth it for you to pursue, otherwise you would have already pursued them.
However,
solutions exist outside of the solutions you are already aware of.
There exists information which you have not yet seen,
and because of this limitation,
you cannot assume that you already have the only answers to your problems.
The reason to pray is to bring new and unknown information into your life in order to hand you information that will give you effortless solutions.

The poet Rumi says that mystics are lazy because they don't have to do anything, everything just comes to them.
This is because they know how to draw everything they need to themselves, into their world.

Know how to ask. Ask to learn how to ask. Pray to learn how to pray.
Pray to learn how to learn how to pray to find solutions.

When you pray for the information you need to solve your problems,
that information will enter your life within a week's time.
When you pray, pray with appreciation and faith, relaxed and expectant,
gracefully, not forcefully.
You don't have to believe prayer will work if you understand that it works,
if you understand that it works, then you don't believe, 

you know that it works, and you know it will work, 

and it does work.

As you gain the solutions to your problems, keep track of them.
Keep track of when you asked for the solution,
when you received the solution, how you received it.
That is the evidence you can start building from.