# The Real You is a Totality

Everyone who is awake enough to realize it knows
That the meaning of enlightenment is not a spiritual phenomena
That life is a totality
The spiritual is not more important than the physical and the physical is not more important than the spiritual. ********

The meaning of enlightenment is what everyone seeks, everyone, even those sleeping through consciousness utter it in their dreams
It is to be awake to your life
It is to understand what you are
It is to be a real person
Even many sleeping people are still aware enough to be a real person, 
even if they do not notice this. 

When I say, a real person,
I mean the totality of a person.
To have known the totality of your person.

This only seems possible if you have set your aim to the highest peak.

It is not a matter of what you become but a matter of what you have experienced of your person. 

People get stuck because they become familiar with a state and remain in it and establish it as their identity

But you aren't your state
You aren't one of the versions of you
You can't say, I am a failure, or I am a winner, I am this or I am that
It's not accurate
You are in a story, and your level of participation in that story is what evokes out versions of your self. 

When I say, set your aims high, 
I don't mean that you become the best  version of you. 

I mean that a real person comes to know an infinite number of versions of themselves.
It is not whether or not you can become something
It is whether or not you activated that something while you were alive.

---

 ****Is a person also like the world?
In which he is always in the center of his life
He can rise higher then the center, 
and lower then the center, 
but he seems to return to the middle
If his highest high grows, his lowest low will also grow, because he comes back to the center of those two points
Then if you want to define him, 
he is not his best self or his worst self.
He is that scope.

---

In the moment, that which is here is what is true
If you are a failure in that moment, 
it is true, your thoughts reflect it, your personality reflects it, the level of cognition you have access to reflects it
When you realize that who you are being in the moment affects the level of cognition you have available to you
Then you can understand something

It means that while you cannot do certain things as who you are in the moment
You cannot determine what you would be capable of if you were a higher version of you, 
you cannot set limits on your capacities because you don't have the mental faculties active inside you that would be operational at that time. 
Those mental faculties would give you expanded abilities that would allow you to operate on that level. 

The way you think, the thoughts you have, the actions you take, all of these would be affected by having access to faculties that you do not have current access to.

How you know yourself determines the faculties that will be evoked, 

the direction you take will affect this. 

---

You've heard this said a thousand times, 
You cannot think of yourself as others are thinking of you right now 
Because they are perceiving you as you are right now

When your reality changes, you change, and what others think about you changes.

What others think about you right now is something that changes, if you watch it day by day you will notice that it is not a constant.

If you aim to make it a constant then you can sustain it

But if you reach out, you remember what people about you said yesterday, 
you see that it has changed, 
If you realize that everyone is sleeping, 
you can realize that they are not keeping track of you every second, they are not a computer always thinking about you, 
they are thinking about themselves, 
as you are thinking about yourself, 
In the dream, you are the only person thinking about yourself all of the time, 
the only person keeping track all the time.

There is often a finality to people's words, and it is true in that reality in that moment, but you notice that the seasons change, and the words change

You see a man, and everyone says, "he lost his edge, he got tired, he isn't what he used to be"

Then a few months later you see the same man, and everyone says, 
"He is doing amazing, he looks so great, he's doing so many things"

They seem to have forgotten what they said before

Because it is not the same reality as before

His reality has changed and their sleeping responses have changed

They are sleeping because they only see right now

You think that what other people think about you will remain always the same
But this changes like seasons

 ****Do not forget that everyone is forgetting

Today I am a fool, tomorrow I am a crazy man, the next day I am wise, the next day I am delusional, the next day I am clarity, the perceptions change, 
what is said changes, 
what is seen changes, 
the picture changes. 

If you can see the picture changes, you can see that you cannot be one of the pictures
You cannot expect that the picture will be the same tomorrow
And if you cannot expect that the picture will be the same tomorrow

Then you have a level of spiritual awareness
Because you know that there are forces that will influence what the picture will be tomorrow
And you can creatively act into today to change what the picture will be tomorrow

---

We all know there is fantasy, that millions pray for a tomorrow that does not come
But millions also pray for a tomorrow that does come

And you know how this is so

It is because the thoughts that come and go by the day are just thoughts, 
 they are just thoughts of the picture of today, they have no impact, they have no influence, they are just thoughts passing by.

It is true, if I ask you to write something down and tell you that this will cause something to happen, 
nothing is probably going to happen.

But if you decided to,

If you understood what it was you were doing,

If you really, really understood how thoughts affect reality and the nature and construction of thought

*"But I don't really understand how thoughts affect reality, I don't have that understanding, 
I am not intelligent enough for that. 
And I don't really believe that thoughts affect reality."* 

You can dissect this very statement.

What does this person believe?

What do they think?

What limitations do they believe they have?

What is stopping them from information?

You have the ability to analyze your own thinking structures and identify what thinking is causing what results.

At that point you can identify the emotional resistances you have with these thoughts, and realize that you are not your emotions and you do not want them to control your thinking in this way.

And if you can analyze these thinking structures
Then you are not your thinking structures

---

Man's concept of what it means to be conscious is not what it means to be conscious.
His idea is that to be self-aware and aware of his reality makes him conscious,
and there is a level of consciousness necessary to be capable of having this awareness,
but you only have to think about it for a moment to see the problem with this idea,

If you say, I am conscious, even though my perceptions are limited, even though my perspective of reality is limited, even though I can't seem to remember much, even though I'm not really being myself, even though I can't figure anything out, 
and then you say, *"to be more conscious is to be more aware"*, 
okay, so lets increase the awareness, the sensitivity, the attention to detail to this experience, 
so now you're more aware of your limited perspective of reality, now before the experience of your five senses was foggy, it was a blur, 
but now your awareness is far more active, now your experience of your five senses is in full HD. 
How is this being more conscious? 
Your experience is now even more intense then it was before, now it grabs your attention even more, now you're focused even more on that which was distracting you. 
You have increased the depth and meaning of your experience, which is good, 
but you have pushed yourself further into the dream, not farther from it. 
This cannot be more sobering, more clear, to push yourself further into the dream is to become more drunk. 
And we should perhaps become more drunk with life, we should be more aware with life, 
but this is not being conscious, 
this is not waking up from a dream, 
this is overanalyzing the dream.