# “@illumn8n  It was recorded in 1957. I heard it in 1970 and bought the recordings in 1972, then sold them in 1974. See if you can find the whole series "Lead the Field" and listen to it every day for a few minutes. Your life will evolve in very positive ways.”

Date Created: February 18, 2023 5:15 AM
Status: Doing