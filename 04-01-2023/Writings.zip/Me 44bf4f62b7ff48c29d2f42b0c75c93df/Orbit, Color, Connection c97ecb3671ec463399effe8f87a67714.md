# Orbit, Color, Connection

The situation may change but perhaps the same events will always occur,
in such a way that those events always happened, always will happen.

The events I'm referring to are not world events or outcomes,
I'm referring to the event in which one person is in the proximity of another person.

The life circumstances of each person may change, but the meeting location and time does not.

For example,
I make choices that will put me into a different situation of life circumstances,
I could pick job A or job B.
This will change perhaps my status or wealth, 

But I believe that it is predetermined that no matter what choices I make,
I will still be in contact with the same person at the same date and time in history.

This leads me to wonder if we are in orbit.
Just as planets and stars have orbits.

If you understand that what fixes the laws of reality is that everything pulls together,
Gravity pulls us to the earth,
Every connection is pulled together,
then if you have a system of things pulling together,
they have orbits,
if the system of things orbiting is humans,
then it is like we have orbits which will land us around certain people at the same time.

Then it is as though reality constructs itself with circumstances to make that happen.

<aside>
💡 This reminds me of the story that God sends a scorpion across land and sea to inevitably kill a prince.

</aside>

This would also explain why seemingly impossible circumstances occur which prevent other people from contacting a certain person at a certain time.

---

Based on what I saw in my experiences of dimensions,
What determines the orbits around others may be related to "emotional growth".
Imagine that each person is a planet,
and that their planet has colors,
reds and blues and purples and greens,
and at certain times,
the planet grows a little more red,
then when it hits a plateau,
it then travels to where there is an abundance of blue, then it grows a little more blue.

So imagine I have a person with a lot of red,
a person with a lot of green,
a person with a lot of blue.

The person with a lot of blue starts developing in green, so they gravitate to the person with a lot of green.

They do not and perhaps cannot gravitate to the person with a lot of red during that time.

To make this more practical,
let's say that people are not just "very red" or "very blue",
but they have periodic changes in state.
Person A is in a red state,
Person B is in a blue state,
Person C is in a red state.

Persons A and C can connect,
but they cannot connect with person C.

---

To make it more interesting,
consider that each person also has a relationship with each other person in their world,
that for each person,
there is a level of resistance and relatability to connecting with another person.

So,
I have
25% relatability to person A,
50% relatability to person B,
75% relatability to person C.

Let's say that there is an interval to how often I can connect to each person.

Let's say I can make contact with person A 25 times a year,
person B 50 times a year,
person C 75 times a year,
That is an interval of
person A every 15 days,
person B every 7 days,
person C every 4 days.

Let's say there are two major reasons for these intervals.
One, say a person has 1% relatability to me. We are not going to get along, we are almost never going to make contact with one another.

Two, say a person has 99% relatability to me. We are going to get along extremely well,
but let's say we are still almost never going to come in contact with one another.

Why?

When you see a person, you often talk with them, you open your voice to them.
When you don't see a person,
you are not speaking to them,
you are not opening your voice,
you are being silent.

I believe this is far more important than it seems,
maybe even the most important or most beautiful thing I know.

---

There is a kind of trust and intimacy in silence. There is a connection that grows in silence.
Imagine that when I speak, I release energy.
Imagine that the longer I do not speak,
the more I build up energy.

When I open my mouth to speak, I will speak with the intensity of the charge of energy that has been building up in my silence.
If I speak all the time, there is no energy buildup, my speech has no built up energy.

You can think of this just like the way you can bottle up anger.

---

Now imagine that there is a limited part of you, what we call, "being self-aware", and it's aware of itself and aware there are others and it's really not aware of much else, and this is what you call your person.
And so, sometimes you connect with another person, and you don't know why, but it happens and you talk with them and then you go away.

What if there is a deeper you that not only knows why you connected to that person, but it chose to connect with them.
What if there is another layer to you,
that there's a self-aware you that communicates to other self-aware people,

and what if there's a deeper you that also communicates with other people.
What if the deeper you is not confined by limitations of space, and has communication with others regardless of where you are.

So let's imagine that the deeper you is having a grand time,
that it's making plans and dates with the people it wants to grow into deeper relationship with,
and it goes around and makes plans to connect with others at certain times in life.

Now what would the decision criteria be for its choices?

For one, there are certain people it wants to develop with.

For two,
again, this concept that the longer you stay silent, the more energy you're building up.

---

Now let's say that this energy is meaningfulness.
Let's say that the longer you stay silent,
the more meaningful your speech will be.

So imagine there is a really, really, really amazing person.
You would love to spend five minutes with them.

For some reason, reality doesn't seem to allow you to do so,
but if you were able to connect,
it would be amazing.

What if there is already a connection and relationship between you and this amazing person.
Then,
the deeper you, and the deeper them,
are right now enjoying silence together, and waiting for energy to grow in both of you until a peak time when it is going to be most amazing that you both connect.

---

You can shrink this down to the microcosm to see that this is so,
this same kind of relationship and communication development occurs on the micro level as well.

In a meaningful and deep conversation,
you know when to speak something,
and you know when you are forcing yourself through an invisible resistance to release speech that you should not at that time.

We experience that forced speech tangibly seems to rip through the fabric of reality, we say it cuts through the atmosphere.
In romance, this is most apparent.

There are things the heart wants to speak at certain times, and does not want to speak at other times.

Lovers wait for the right moment for a kiss, not too early, a missed opportunity if too late,
an invisible kind of communication based on timing.