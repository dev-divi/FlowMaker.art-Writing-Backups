# Resources

---

# [Resources for Life🌱](Resources%20607aed5abe4d4e8385314fccf2051608/Life%20Resources%20-%20Direction,%20Purpose,%20Meaning%20aeb3f20889b247d3a2e01242d56edbc2.md)

[Recovery Services in Portland Oregon - February 2023](https://docs.google.com/document/d/1ctKq0xmDmx6XcB4t3z9qoZokPuCwCLIz6xIGQGdagoo/edit)

[Life Resources - Direction, Purpose, Meaning](Resources%20607aed5abe4d4e8385314fccf2051608/Life%20Resources%20-%20Direction,%20Purpose,%20Meaning%20aeb3f20889b247d3a2e01242d56edbc2.md)

---

# [Hack Skills💡](Resources%20607aed5abe4d4e8385314fccf2051608/Skills%204bf1d46e43a54866ae26e225d73ef836.md)

[Skills](Resources%20607aed5abe4d4e8385314fccf2051608/Skills%204bf1d46e43a54866ae26e225d73ef836.md)

[Generating Receptivity](Resources%20607aed5abe4d4e8385314fccf2051608/Generating%20Receptivity%2063352da7db71440aa1ae85b6db8b4ff0.md)

---