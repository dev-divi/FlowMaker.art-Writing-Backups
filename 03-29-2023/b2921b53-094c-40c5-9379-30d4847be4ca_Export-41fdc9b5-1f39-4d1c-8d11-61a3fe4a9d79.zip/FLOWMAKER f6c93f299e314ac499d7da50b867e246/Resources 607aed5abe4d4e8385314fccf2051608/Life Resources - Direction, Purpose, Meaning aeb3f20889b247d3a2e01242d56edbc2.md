# Life Resources - Direction, Purpose, Meaning

- Searching for Direction - [Jordan Peterson Speech - YouTube](https://youtu.be/wqEsTPaUZF0)
- Searching for Meaning - [Man's Search for Meaning](https://www.goodreads.com/book/show/4069.Man_s_Search_for_Meaning)
- Searching for Purpose - [Finding Purpose - YouTube](https://youtu.be/NuHEY7CjjTI)