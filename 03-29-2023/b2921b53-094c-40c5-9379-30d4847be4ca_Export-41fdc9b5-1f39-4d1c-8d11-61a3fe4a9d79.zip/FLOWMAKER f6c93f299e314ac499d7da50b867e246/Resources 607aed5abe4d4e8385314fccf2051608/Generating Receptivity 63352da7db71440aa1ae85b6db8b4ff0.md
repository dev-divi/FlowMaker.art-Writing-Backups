# Generating Receptivity

Listen genuinely and others will desperately desire to genuinely hear you.

Yeah this sounds all nice and all but when none of us know how to do this, it doesn't really help much.

Well as it turns out, some people do know how to use this and it's quite the lucrative skill to have in your arsenal. Add the skills to your life that improve your quality of life and you have effectively changed your life.

This skill is relatively new. No one person holds every piece to it. The one who can learn this can take the gold from available sources of information. If you learn this, you are among the few people in this world to even know that this superpower exists.

# 1 - Listening is the Golden Key.

Recommend watching at 2x speed

[https://www.youtube-nocookie.com/embed/saXfavo1OQo](https://www.youtube-nocookie.com/embed/saXfavo1OQo)

# 2 - Reflective Power

Recommend watching at 2x speed

[https://www.youtube-nocookie.com/embed/A343tlP5iUA](https://www.youtube-nocookie.com/embed/A343tlP5iUA)

# 3 - Achieve Authenticity

It's not being who you want to be, it's being who you are.

If you are seen and heard, they can be seen and heard.

Recommend watching at 1.75X speed

[https://www.youtube-nocookie.com/embed/X4Qm9cGRub0](https://www.youtube-nocookie.com/embed/X4Qm9cGRub0)

# 4 - Master Presence

Pause and accept one's reality to learn and communicate with them. Allow life to flow through you and life becomes magic.

Recommend watching at 1.75X speed

[https://www.youtube-nocookie.com/embed/Yq5pJ0q3xuc](https://www.youtube-nocookie.com/embed/Yq5pJ0q3xuc)

# Additional Keys

**Decimate Shame - Brene Brown**

[https://www.youtube-nocookie.com/embed/psN1DORYYV0](https://www.youtube-nocookie.com/embed/psN1DORYYV0)](https://www.youtube-nocookie.com/embed/psN1DORYYV0](https://www.youtube-nocookie.com/embed/psN1DORYYV0))

**Using Empathy - Brene Brown**

[https://www.youtube-nocookie.com/embed/1Evwgu369Jw](https://www.youtube-nocookie.com/embed/1Evwgu369Jw)](https://www.youtube-nocookie.com/embed/1Evwgu369Jw](https://www.youtube-nocookie.com/embed/1Evwgu369Jw))