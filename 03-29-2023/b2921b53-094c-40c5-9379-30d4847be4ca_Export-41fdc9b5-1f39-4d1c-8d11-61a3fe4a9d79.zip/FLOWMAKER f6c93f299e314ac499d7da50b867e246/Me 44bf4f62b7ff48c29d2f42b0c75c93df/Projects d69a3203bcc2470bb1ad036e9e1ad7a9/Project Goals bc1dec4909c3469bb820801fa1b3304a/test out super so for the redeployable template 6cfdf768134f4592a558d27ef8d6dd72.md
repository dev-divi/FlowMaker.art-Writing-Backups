# test out super.so for the redeployable template

Date Created: February 16, 2023 5:56 PM
Status: Done 🙌