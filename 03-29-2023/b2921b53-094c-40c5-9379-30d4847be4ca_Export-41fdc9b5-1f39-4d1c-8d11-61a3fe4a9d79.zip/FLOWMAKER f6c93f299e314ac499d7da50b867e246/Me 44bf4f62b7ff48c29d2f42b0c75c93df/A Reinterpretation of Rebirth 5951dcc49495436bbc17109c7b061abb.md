# A Reinterpretation of Rebirth

I believe that the "saving of souls" mission of Christianity is not as *‘fantastical’* as it seems. I understand it to be the case that your spirit does need to be "activated" for you to not simply return to the dust of the earth from which you came. 

You do have to have your spirit activated within you in order for that connection to be established permanently. 
Just like an on/off switch, the switch does need to turn on, the electrical connection does have to have a direct line.

 A more philosophical way to say this, 
is that *you can't exist if you never knew who you were*.

That *you can't die if you never were alive* is like saying, 
*you can't fall back asleep if you never woke up.*

If you read the scriptures considering this interpretation you will see that this is the case. 
This is why the scriptures say there are two baptisms, 
"I baptize you with water, but one is coming who will baptize you with fire". 

This is the fire of Spirit, it is also awakening and it burns up everything which is not of oneness, 
it is your true self.

The water baptism is basically the death of the self into a first rebirth of man into his real nature, 
This second baptism is basically the awakening of spirit. 

When man awakens he escapes the prison of false reality, he is not controlled by his lower self, **his life is led by his real human spirit.** 

*False teachers* are basically just people whose spirits are asleep. 

They have never known spirit so they are teaching a way their mind and self understands.