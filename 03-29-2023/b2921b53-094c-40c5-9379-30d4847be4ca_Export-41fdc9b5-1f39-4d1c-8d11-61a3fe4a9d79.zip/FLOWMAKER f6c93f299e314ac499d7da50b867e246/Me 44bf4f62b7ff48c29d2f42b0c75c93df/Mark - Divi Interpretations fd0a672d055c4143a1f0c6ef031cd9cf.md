# Mark - Divi Interpretations

## Part I

In my understanding, Christ referred to Satan as the mind of man,
and would have called all of the church and its understandings Satan.

Christ quotes scripture, *Seeing they may see and not perceive,  And hearing they may hear and not understand;  Lest they should turn,  And their sins be forgiven them."*
And He said to them,
*Do you not understand this parable?  How then will you understand all the parables?*

The meaning of the parable is that an open heart sees, hears, understands,
and forgives. Without the key, the open heart, no other parable will be able to be understood.

He goes on, *The sower sows the word.* [The message of the heart]
*And these are the ones by the way-side where the word is sown. When they hear,  Satan comes immediately and takes away the word that was sown in their hearts..they receive it with gladness, and they have no root in themselves, so they last only a time. Afterward, when trial of persecution arises for the word's sake, immediately they stumble.*
This parable goes on,
but I see that this Satan that comes is the mind of man and the thoughts of man.
This means that there is not these people or those people, but there is 'the mind of the mind' and the mind of the heart. 
The ‘mind of the mind’ is what this world sometimes calls 'Adamic Consciousness', the consciousness of man.
The mind of the heart seems related to compassion, the right brain,

<aside>
💡 possibly even related to hallucinogenic mushrooms according to Terrence McKenna's theory.

</aside>

Christ condemns the church priests as hypocrites, quoting Isaiah,
*This people honors Me with their lips,  But their heart is far from Me.  And in vain they worship Me,  Teaching as doctrines the commandments of men.*

I understand this to be the folly of the church,
that the church is composed of men, and men teach their beliefs and cultural customs through scripture, using scripture to display the way they view the world. They interpret scripture based on their cultural belief system, and teach their ways through scripture.
They teach the commandments of men, the commandments of society, as doctrine, as the word. 

Christ again uses the word Satan when he rebukes Peter, saying,
*`Get behind Me, Satan! For you are not mindful of the things of God, but the things of men."*

Again, Christ refers to Satan as the mind of man, not the heart.
I use the word heart as a placeholder for what can arise from the heart,
but in any case, it is my understanding that spiritual blindness is the blindness that comes from the limitations of man's mind, that sight is a sight which comes out of an open heart. This is evidenced by most of the bible calling out as wicked those who have closed hearts.

I continually speak of this because it is this that allows you to see why you ought not to judge the scripture based on the church that misrepresents it,
the church is of the mind of man, they are not *spiritual*.

## Part II

A scribe asked Christ which is the highest commandment, and Christ answered,
*"The first of all the commandments is,[quoting Moses] "Hear O Israel, the Lord our God, the Lord is one. And you shall love the Lord your God with all your heart, with all your soul, with all your mind, and with all your strength."*
The scribe replies, *"You have spoken the truth, for there is one God, and there is no other but He. And to love Him with all the heart, with all the soul, with all the understanding, with all the soul, and with all the strength.. is more than all the whole burnt offerings and sacrifices."*
Christ  saw that he answered wisely and replies,*"You are not far from the kingdom of God."*

I believe Christ had kindness on this man, for he was a blind man.
He hears but could not hear. He saw but could not see.
Christ says, "God is one."
The scribe retranslates, "There is one God."
Christ's commandment is to love the loving God with everything.
The scribe understands to love one god with everything.

Christ says he is not far from the kingdom of God,
but this may be a double edged sword,
to be a step away from the kingdom is also eternally far away.

The scribe hears with his mind, and he has a good heart,
and Christ loves this man for it.
But the scribe is not listening with his heart, he is still only hearing with his mind.
Even so, he has still oriented his mind and heart in the right direction,
he is still good, he is just limited, without the key of the heart's ear,
he cannot access the kingdom of God.

## Part III

Christ tells a parable,
*It is like a man going to a far country, who left his house and gave authority to his servants, and to each his work, and commanded the doorkeper to watch. You don't know when the master of the house is coming..*
This parable is the beginning of a parable from the masters in Indian religions, though Christ simplifies the ending.

## Part IV

Christ's soul falls into sorrow, and walks in the valley of death,
there is no kingdom of heaven in sight.
He prays,
*"Abba, Father, all things are possible for You.
Take this cup away from Me; nevertheless, not what I will, but what You will."*
In this prayer may be the key  to accessing the kingdom of heaven from
a lower state of consciousness.

## Part V

In Mark, When Christ has disappeared from the tomb, and Mary and women come to the tomb, they discover, *a young man clothed in a long white robe sitting on the right side; and they were alarmed.*
In Luke, *"Two men stood by them in shining garments. They were afraid and bowed their faces to the earth."*
In John, *"She saw two angels in white sitting, one at the head and the other at the feet, where the body of Jesus had lain."*
In Matthew, *an angel of the Lord descended from heaven, and came and rolled back the stone from the door, and sat on it. His countenance was like lightning, and his clothing as white as snow. And the guards shook for fear of him, and became like dead men.*

The gospels speak of a men or men dressed in white robes.
Is it possible that Christ was not working alone?