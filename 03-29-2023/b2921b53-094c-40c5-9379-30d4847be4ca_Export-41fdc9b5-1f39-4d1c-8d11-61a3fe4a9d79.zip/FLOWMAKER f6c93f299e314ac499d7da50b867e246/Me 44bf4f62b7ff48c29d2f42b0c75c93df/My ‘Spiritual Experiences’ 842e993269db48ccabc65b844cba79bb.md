# My ‘Spiritual Experiences’

I am 28 years old now, 
though I have had experiences of eternity for lengths of time that I cannot quantify. 

I had exposure to an evangelical church early on, 
had an ego death from mushrooms at 16, 
I experienced the dimensions and the abyss when I was around 21 so it's been about 7 years into a “spiritual journey”. 

In the inner world I've been to hell, been beyond thought, seen the godheads, heard direct thoughtless information, gone into states of gnosis, seen the eyes of Christ, seen pure infinite information, experienced god presence, holy spirit presence, glory presence, oil presence, 
more experiences than this. 

In the outer world, I have seen reality in just as profound ways. Most important is that there is a tangible reality in which there exists eternal life,  and which the kingdom of the heavens becomes one with the physical plane. 
I call this Presence or Consciousness, 

In that reality which is coming, 
there is only perfection, infinite and instant revelation of meaning, infinitely meaningful experiences that come at a rate of perfect flow from one to the next, all good things of reality come together such as family and connection, there is no suffering, there is nothing but fulfillment and miracles and possibilities of destiny transpiring, 
there is no darkness, no fear, no injury, 
that's all on the outside, 
on the inside there is infinite healing of all wounds, there is the pure and perfect person that is complete and loved, a life which is a celebration of the miracle of existence itself. 

The way this happens makes it a definitive outcome that all realities dissolve into the actual Reality. 
This is because when Reality comes, 
it is like a wave of truth which evaporates any untruth that had appeared before it,

And these waves will and do spill out from the real world into the physical and currently filled with falsity world,
but there will be a time coming when that Reality is an ocean that floods the earth, 

I could say that there is a higher reality that has a greater density then lower reality, and that that density will absorb the lower density. 

# A Reinterpretation of Afterlife

I believe there is a misinterpretation of hell. 

The fire of hell is also the fire of heaven. The fire of hell is the exposure to Reality. It burns up everything that is not perfect. 
Every time you experience any kind of healing through god, fire burns out the wounds within you. 
It is true that if there is nothing good in a person, when the fire comes, by definition there will be nothing left of that person. 

To say this again, all of your imperfections and weaknesses doubts fears failures everything that is not of real life is absorbed into real life, what actually exists. 

This is why meditation is on such a great track is it at least gets in tune with what actually exists, 
however that does not mean the meditator is in contact with that Reality. 

# A Reinterpretation of Rebirth

I believe that the "saving of souls" mission of Christianity is not as *‘fantastical’* as it seems. I understand it to be the case that your spirit does need to be "activated" for you to not simply return to the dust of the earth from which you came. 

You do have to have your spirit activated within you in order for that connection to be established permanently. 
Just like an on/off switch, the switch does need to turn on, the electrical connection does have to have a direct line.

 A more philosophical way to say this, 
is that *you can't exist if you never knew who you were*.

That *you can't die if you never were alive* is like saying, 
*you can't fall back asleep if you never woke up.*

If you read the scriptures considering this interpretation you will see that this is the case. 
This is why the scriptures say there are two baptisms, 
"I baptize you with water, but one is coming who will baptize you with fire". 

This is the fire of Spirit, it is also awakening and it burns up everything which is not of oneness, 
it is your true self.

The water baptism is basically the death of the self into a first rebirth of man into his real nature, 
This second baptism is basically the awakening of spirit. 

When man awakens he escapes the prison of false reality, he is not controlled by his lower self, his life is led by his real human spirit. 

*False teachers* are basically just people whose spirits are asleep. 

They have never known spirit so they are teaching a way their mind and self understands.

# A Reinterpretation of Way

The reason why it is said that there is only one way to find god is not because there is a correct religion. It is because in infinity there is only one direction that points to the real you. 

Consider this. Is there a real you? 
If there is a real you, if there is one real you, 
then there is only one way, the way to the real you. 
If you point a way in a different direction, you would arrive at a different destination. 

The way I am speaking of is a way of action and nature, 
If you do have a real spirit, that spirit has a way, 
there are many ways you could take but only one way is the way of your spirit. 

There are many paths you can take but there are only two directions that path can take you, you can either go closer to the real you, or farther from the real you. 

So this fire that comes, what it does is it kills what isn't the real you. 

In actuality this is just a poetic way to say that what is not real disappears because it is not real.

What this all means philosophically speaking is that you are good and worthy and deserving of life because you are life.

This is why they were badly mistaken, *his God was not the god of the dead but of the living.*

Another way to say it is that **the real you is the ultimate possibility of your existence.**

And **the ultimate possibility of your existence is life,** 
that **the miracle of life is the ultimate possibility of existence.**

> *"There is nothing you can get in life without paying for it, 
And you get it only as much as you are ready to pay for it. 
When you are willing to pay your life, you get eternal life in return. 
Nothing is free. Nothing can be free."*
>