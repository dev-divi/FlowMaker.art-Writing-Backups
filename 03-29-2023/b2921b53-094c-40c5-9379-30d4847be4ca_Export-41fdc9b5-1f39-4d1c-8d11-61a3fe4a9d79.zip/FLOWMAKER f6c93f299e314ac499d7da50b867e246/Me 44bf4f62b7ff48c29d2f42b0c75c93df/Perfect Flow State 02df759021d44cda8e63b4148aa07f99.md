# Perfect Flow State

I see a perfect flow possible when a person's words line up with their actualized way of being as they live their life.

If a person's words line up with their actions, and their actions line up with reality,

then one can live inside of the flow state.

Consider that when one is in the state of perfect flow, 

they are no longer thinking, 

they are performing the task perfectly, 

perhaps music, perhaps dance, perhaps work, 

their action and their thought blend together as one silent and perfect movement.

The one who pursues what I am talking about then, 

the pursuit of becoming real, 

the destination is a life that is perfect flow.

This is what allows a Zen master to remain in a state of such water-like quality.

As the way becomes perfect,

the thoughts become perfect,

as the thoughts become perfect, 

the actualized thoughts as action become more perfect.

The thoughts become perfect as the mind becomes associated with **the present state of consciousness, the current reality**,

and less associated with subjective information watered down by the individual.